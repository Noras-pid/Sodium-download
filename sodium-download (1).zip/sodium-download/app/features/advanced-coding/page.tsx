import Link from 'next/link'
import { Code } from 'lucide-react'
import { motion } from 'framer-motion'

export default function AdvancedCoding() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-black text-gray-300 p-8">
      <Link href="/" className="text-blue-400 hover:text-blue-300 transition-colors">&larr; Back to Home</Link>
      <motion.div 
        className="max-w-3xl mx-auto mt-12"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl font-bold mb-6 flex items-center">
          <Code className="w-10 h-10 mr-4 text-blue-400" />
          <span className="bg-gradient-to-r from-blue-400 to-cyan-500 bg-clip-text text-transparent">
            Advanced Coding
          </span>
        </h1>
        <p className="text-xl mb-8 leading-relaxed">
          Sodium's Advanced Coding feature empowers developers with cutting-edge tools and techniques to enhance their coding capabilities. From intelligent code completion to advanced debugging tools, we provide everything you need to take your coding skills to the next level.
        </p>
        <h2 className="text-2xl font-semibold mb-4 text-blue-400">Key benefits of Advanced Coding:</h2>
        <ul className="list-disc list-inside space-y-4 mb-8">
          <li>AI-powered code completion: Get context-aware suggestions as you type, speeding up your coding process.</li>
          <li>Advanced static analysis: Detect potential bugs and code smells before they become issues.</li>
          <li>Interactive debugging: Step through your code with powerful visualization tools for easier problem-solving.</li>
          <li>Code transformation: Easily refactor and modernize legacy code with automated tools.</li>
          <li>Collaborative coding: Real-time code sharing and pair programming features for seamless teamwork.</li>
        </ul>
        <p className="text-lg mb-8">
          With Sodium's Advanced Coding features, you'll have the tools you need to tackle complex programming challenges with confidence. Elevate your coding skills and produce higher quality software faster than ever before.
        </p>
        <motion.div
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <Link href="/" className="bg-gradient-to-r from-blue-400 to-cyan-500 hover:from-blue-500 hover:to-cyan-600 text-white font-bold py-3 px-6 rounded-full transition-colors inline-block">
            Enhance Your Coding with Sodium
          </Link>
        </motion.div>
      </motion.div>
    </div>
  )
}

