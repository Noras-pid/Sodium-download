import Link from 'next/link'
import { Zap } from 'lucide-react'
import { motion } from 'framer-motion'

export default function LightningSpeed() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-black text-gray-300 p-8">
      <Link href="/" className="text-blue-400 hover:text-blue-300 transition-colors">&larr; Back to Home</Link>
      <motion.div 
        className="max-w-3xl mx-auto mt-12"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl font-bold mb-6 flex items-center">
          <Zap className="w-10 h-10 mr-4 text-yellow-400" />
          <span className="bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
            Lightning Speed
          </span>
        </h1>
        <p className="text-xl mb-8 leading-relaxed">
          Sodium's Lightning Speed feature optimizes your development workflow for maximum efficiency. 
          Experience blazing-fast performance that will revolutionize your coding experience. Our advanced optimization techniques and cutting-edge algorithms ensure that every operation, from compilation to deployment, is executed with unparalleled speed.
        </p>
        <h2 className="text-2xl font-semibold mb-4 text-yellow-400">Key benefits of Lightning Speed:</h2>
        <ul className="list-disc list-inside space-y-4 mb-8">
          <li>Instant code execution: See your changes in real-time as you type, eliminating long wait times for compilation and rendering.</li>
          <li>Rapid project builds: Compile and build your entire project in a fraction of the time it takes with traditional tools.</li>
          <li>Seamless integration: Lightning Speed works harmoniously with your existing development environment, enhancing performance without disrupting your workflow.</li>
          <li>Intelligent caching: Our smart caching system remembers your frequently used resources, reducing load times and improving overall efficiency.</li>
          <li>Optimized resource management: Sodium intelligently allocates system resources to ensure smooth performance even when working on complex projects.</li>
        </ul>
        <p className="text-lg mb-8">
          By leveraging the power of Lightning Speed, you'll be able to focus more on creating and less on waiting. Boost your productivity and bring your ideas to life faster than ever before with Sodium's Lightning Speed feature.
        </p>
        <motion.div
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <Link href="/" className="bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-black font-bold py-3 px-6 rounded-full transition-colors inline-block">
            Get Started with Lightning Speed
          </Link>
        </motion.div>
      </motion.div>
    </div>
  )
}

