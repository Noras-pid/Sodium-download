import Link from 'next/link'
import { Shield } from 'lucide-react'
import { motion } from 'framer-motion'

export default function IroncladSecurity() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-black text-gray-300 p-8">
      <Link href="/" className="text-blue-400 hover:text-blue-300 transition-colors">&larr; Back to Home</Link>
      <motion.div 
        className="max-w-3xl mx-auto mt-12"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl font-bold mb-6 flex items-center">
          <Shield className="w-10 h-10 mr-4 text-green-400" />
          <span className="bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent">
            Ironclad Security
          </span>
        </h1>
        <p className="text-xl mb-8 leading-relaxed">
          Sodium's Ironclad Security feature provides built-in protection against modern threats, keeping your projects safe and secure. Our comprehensive security measures ensure that your development environment and applications are fortified against potential vulnerabilities and attacks.
        </p>
        <h2 className="text-2xl font-semibold mb-4 text-green-400">Key benefits of Ironclad Security:</h2>
        <ul className="list-disc list-inside space-y-4 mb-8">
          <li>Advanced encryption: Protect your code and data with state-of-the-art encryption algorithms.</li>
          <li>Vulnerability scanning: Automatically detect and alert you to potential security risks in your codebase.</li>
          <li>Secure dependencies: Ensure that all third-party libraries and packages are vetted for security issues.</li>
          <li>Access control: Implement granular access controls to manage user permissions and protect sensitive information.</li>
          <li>Real-time threat monitoring: Continuously monitor your development environment for suspicious activities and potential breaches.</li>
        </ul>
        <p className="text-lg mb-8">
          With Sodium's Ironclad Security, you can focus on building great software without worrying about security vulnerabilities. Our comprehensive protection ensures that your projects remain safe from conception to deployment.
        </p>
        <motion.div
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <Link href="/" className="bg-gradient-to-r from-green-400 to-emerald-500 hover:from-green-500 hover:to-emerald-600 text-black font-bold py-3 px-6 rounded-full transition-colors inline-block">
            Secure Your Development with Sodium
          </Link>
        </motion.div>
      </motion.div>
    </div>
  )
}

