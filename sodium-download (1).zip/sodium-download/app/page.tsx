'use client'

import React, { useState, useEffect } from 'react'
import { motion, useViewportScroll, useTransform } from 'framer-motion'
import { ArrowDownToLine, Github, Zap, Shield, Cpu, Code, Atom } from 'lucide-react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'

export default function Home() {
  const [isScrolled, setIsScrolled] = useState(false)
  const { scrollY } = useViewportScroll()
  const opacity = useTransform(scrollY, [0, 100], [0, 1])
  const router = useRouter()

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const handleDownload = () => {
    alert("Downloading Sodium... This would typically start the actual download.")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-black text-gray-300">
      <header className={`fixed top-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-black/50 backdrop-blur-md' : ''}`}>
        <nav className="max-w-7xl mx-auto p-6">
          <div className="flex justify-between items-center">
            <motion.div 
              className="flex items-center space-x-2"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Atom className="w-8 h-8 text-blue-500" />
              <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
                Sodium
              </h1>
            </motion.div>
            <motion.div
              className="flex items-center gap-6"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
            >
              <a href="https://github.com" target="_blank" rel="noopener noreferrer" 
                className="p-2 hover:bg-gray-800 rounded-full transition-colors">
                <Github className="w-6 h-6" />
                <span className="sr-only">GitHub</span>
              </a>
            </motion.div>
          </div>
        </nav>
      </header>

      <main className="pt-24">
        <section className="max-w-7xl mx-auto px-6 py-24">
          <motion.div 
            className="text-center space-y-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
          >
            <motion.h2 
              className="text-5xl sm:text-6xl md:text-7xl font-extrabold"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
            >
              <span className="bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 bg-clip-text text-transparent gradient-text-animation">
                Download Sodium
              </span>
            </motion.h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Experience a new level of performance with Sodium - 
              the cutting-edge tool for modern development.
            </p>
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <button 
                onClick={handleDownload}
                className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-bold py-4 px-8 rounded-full text-lg shadow-lg hover:shadow-xl transition-all duration-300 glow-effect"
              >
                <ArrowDownToLine className="inline-block mr-2 h-6 w-6" /> Download Sodium
              </button>
            </motion.div>
          </motion.div>
        </section>

        <section className="max-w-7xl mx-auto px-6 py-24">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.2, duration: 0.5 }}
              >
                <div className="p-6 bg-gray-800 rounded-xl hover:bg-gray-700 transition-colors duration-300 h-full flex flex-col justify-between group">
                  <div>
                    <feature.icon className="w-12 h-12 mb-4 text-blue-400 group-hover:text-blue-300 transition-colors duration-300" />
                    <h3 className="text-xl font-bold mb-2 text-gray-200">{feature.title}</h3>
                    <p className="text-gray-400">{feature.description}</p>
                  </div>
                  <motion.div
                    whileHover={{ x: 5 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Link href={`/features/${feature.title.toLowerCase().replace(/\s+/g, '-')}`} className="mt-4 text-blue-400 hover:text-blue-300 transition-colors inline-block">
                      Learn more &rarr;
                    </Link>
                  </motion.div>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        <section className="max-w-7xl mx-auto px-6 py-24 bg-gray-800 rounded-xl">
          <motion.div 
            className="text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
          >
            <h2 className="text-3xl font-bold mb-8 text-gray-200">Join the Community</h2>
            <div className="flex flex-wrap justify-center gap-4">
              <motion.a 
                href="https://github.com"
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full hover:from-blue-600 hover:to-purple-700 transition-all duration-300 shadow-lg hover:shadow-xl"
              >
                <Github className="inline-block mr-2 h-5 w-5" /> GitHub
              </motion.a>
            </div>
          </motion.div>
        </section>

        <section className="max-w-7xl mx-auto px-6 py-24">
          <motion.div 
            className="text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
          >
            <h2 className="text-3xl font-bold mb-8 text-gray-200">Ready to Get Started?</h2>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-8 py-4 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full hover:from-blue-600 hover:to-purple-700 transition-all duration-300 shadow-lg hover:shadow-xl text-lg font-bold glow-effect"
              onClick={() => router.push('/docs')}
            >
              Try Sodium Now
            </motion.button>
          </motion.div>
        </section>
      </main>

      <footer className="border-t border-gray-800 bg-black">
        <div className="max-w-7xl mx-auto px-6 py-12">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-500">&copy; 2024 Sodium Project. All rights reserved.</p>
            <div className="flex gap-4">
              <Link href="/privacy" className="text-gray-500 hover:text-gray-300 transition-colors">Privacy</Link>
              <Link href="/terms" className="text-gray-500 hover:text-gray-300 transition-colors">Terms</Link>
              <Link href="/contact" className="text-gray-500 hover:text-gray-300 transition-colors">Contact</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

const features = [
  {
    title: "Lightning Speed",
    description: "Optimized performance for maximum efficiency in your development workflow.",
    icon: Zap
  },
  {
    title: "Ironclad Security",
    description: "Built-in protection against modern threats to keep your projects safe.",
    icon: Shield
  },
  {
    title: "Smart Optimization",
    description: "Automatic resource optimization to streamline your development process.",
    icon: Cpu
  },
  {
    title: "Advanced Coding",
    description: "Cutting-edge coding features to enhance your development capabilities.",
    icon: Code
  }
]

