'use client'

import { motion } from "framer-motion"
import Link from "next/link"

export default function NotFound() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-800 flex items-center justify-center p-4">
      <div className="flex flex-col md:flex-row items-center justify-center gap-4 md:gap-8 bg-black/30 backdrop-blur-lg p-8 rounded-xl">
        <motion.h2 
          className="text-6xl md:text-8xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          404
        </motion.h2>
        <motion.div 
          className="h-px md:h-16 w-16 md:w-px bg-white/20"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2 }}
        />
        <motion.div
          className="flex flex-col items-center md:items-start gap-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.5 }}
        >
          <p className="text-xl md:text-2xl text-white text-center md:text-left">This page could not be found.</p>
          <Link 
            href="/"
            className="text-blue-400 hover:text-blue-300 transition-colors underline text-lg"
          >
            Return Home
          </Link>
        </motion.div>
      </div>
    </div>
  )
}

